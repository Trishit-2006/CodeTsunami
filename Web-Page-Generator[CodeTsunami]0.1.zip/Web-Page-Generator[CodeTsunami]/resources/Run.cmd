@ECHO OFF
java -jar .binary-file