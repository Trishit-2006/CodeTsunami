@ECHO OFF
cd resources/
Run.cmd

